﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpSeleniumFramework.pageObjects
{
    public class CulturePage
    {
        private IWebDriver driver;
        public CulturePage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//body/div[@id='orb-footer']/footer[1]/div[1]/div[1]/div[1]/small[1]")]
        private IWebElement downscroll;

        //scroll
        //IWebElement frameScroll = driver.FindElement(By.Id("courses-iframe")); 
        public String scroll()
        {
            Thread.Sleep(3000);
            IWebElement frameScroll = downscroll;
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver; 
            js.ExecuteScript("arguments[0].scrollIntoView(true);", frameScroll);

            String x = downscroll.Text;
            return x;



        }

    }
}
