﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpSeleniumFramework.pageObjects
{
    public class HomePage
    {
        private IWebDriver driver;
        public HomePage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        //Pageobject Factory

        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'More')]")]
        private IWebElement morebutton;


        

        [FindsBy(How = How.XPath, Using = "//body/div[@id='cookiePrompt']/section[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/button[1]/span[2]")]
        private IWebElement consentbutton;

        [FindsBy(How = How.XPath, Using = "//body/div[@id='orb-modules']/div[@id='root']/div[2]/div[1]/nav[1]/div[1]/div[2]/div[1]/div[2]/a[3]/p[1]")]
        private IWebElement artbutton;
        public void getMorebutton()
        {
            consentbutton.Click();
            morebutton.Click();
        }

        public CulturePage getArtbutton()
        {
            artbutton.Click();
            return new CulturePage(driver);
            //return new ArtPage(driver);
        }

    }
}
