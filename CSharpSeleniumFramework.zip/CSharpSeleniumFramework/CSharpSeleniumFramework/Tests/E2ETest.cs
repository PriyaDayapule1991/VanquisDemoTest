﻿using CSharpSeleniumFramework.pageObjects;
using CSharpSeleniumFramework.Utilites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpSeleniumFramework.Tests
{
    public class E2ETest:baseclass
    {
        [Test]
        public void Test1()
        {
            HomePage homePage = new HomePage(driver);
            homePage.getMorebutton();
           CulturePage culturePage= homePage.getArtbutton();

            String actual=culturePage.scroll();
           Console.WriteLine(actual);
            String expected = "Copyright © 2022 BBC. The BBC is not responsible for the content of external sites. Read about our approach to external linking.";
            StringAssert.Contains(expected, actual);


        }

    }
}
